# Start a simple HTTP server on port 8080 using Python 3
python -m http.server 8080