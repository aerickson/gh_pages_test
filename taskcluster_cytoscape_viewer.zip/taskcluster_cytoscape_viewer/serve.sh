#!/usr/bin/env bash

set -e

python3 -m http.server 8080

